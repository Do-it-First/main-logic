## Frontend

-   `npm run start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

<br/>

### To Get Started

-   명령어로 frontend repo에 진입

```js
cd ../main-logic/frontend
```

`npm install` 을 통하여 필요한 모듈을 설치한다.
